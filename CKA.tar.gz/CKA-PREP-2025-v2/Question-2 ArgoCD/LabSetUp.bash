#!/bin/bash
echo "# For this lab you can just use the killercoda playground as it is, no adjustments needed"
