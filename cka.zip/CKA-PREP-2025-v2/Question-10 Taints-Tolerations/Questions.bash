# Question: Taints & Tolerances

# Tasks:
# 1. Add a taint to node01 so tht no normal pods can be scheduled in this node. key=PERMISSION, value=granted, Type=NoSchedule
# 2. Schedule a Pod on node01 adding the correct toleration to the spec so it can be deployed

# Video Link - https://youtu.be/oy6Mdqt1-jk
