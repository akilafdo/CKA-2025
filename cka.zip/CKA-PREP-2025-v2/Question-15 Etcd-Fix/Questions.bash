# Question:
# After a cluster migration, the controlplane kube-apiserver is not coming up
# Before the migration, the etcd was external and in HA, after migration the kube-api server was pointing to etcd peer port 2380

# Task
# Fix it

# Video Link - https://youtu.be/IL448T6r8H4
